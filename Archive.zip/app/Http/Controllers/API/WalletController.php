<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use App\Wallet;
use App\WalletTransaction;
use DB;

class WalletController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getWallet()
    {
        $userId = Auth::user()->id;
        try {
            $wallet = Wallet::where('user_id', $userId)->first();

            return response()->json([
                'success' => true,
                'message' => 'Successfully get Wallet information',
                'data' => $wallet
            ]);
        } catch(\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }

    public function addBalance(Request $request) {
        $amount = $request->get('amount');
        $paymentMethod = $request->get('payment_method');
        $user = User::where('id', Auth::user()->id)->with('wallet')->first();
        try {
            DB::beginTransaction();
            $transaction = new WalletTransaction;
            $transaction->wallet_id = $user->wallet->id;
            $transaction->amount = $amount;
            $transaction->transaction_type = 'incoming';
            $transaction->payment_method = $paymentMethod;
            $transaction->save();

            $wallet = Wallet::find($transaction->wallet_id);
            $wallet->balance += $transaction->amount;
            $wallet->save();
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Successfully add balance',
                'data' => $transaction
            ]);
        } catch(\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }

}
