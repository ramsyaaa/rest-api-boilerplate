<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wallet extends Model
{
    

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'wallets';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['user_id', 'balance', 'currency'];

    protected $hidden = ['id', 'user_id' ,'created_at', 'updated_at'];

    

}
